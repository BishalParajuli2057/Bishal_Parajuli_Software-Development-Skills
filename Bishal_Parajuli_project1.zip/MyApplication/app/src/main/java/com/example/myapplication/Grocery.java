package com.example.myapplication;

public class Grocery {
    private String name;
    private String note;
    private boolean important;
    public Grocery(String name, String note, boolean isImportant) {
        this.name = name;
        this.note = note;
        this.important = isImportant;
    }

    public boolean isImportant() {
        return important;
    }

    public String getName(){
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }
}
