package com.example.myapplication;

import java.util.ArrayList;
import java.util.Comparator;

public class ListGrocery {
    private static final ListGrocery instance = new ListGrocery();
    private final ArrayList<Grocery> groceries = new ArrayList<>();

    private ListGrocery() {}

    public static ListGrocery getInstance() {
        return instance;
    }

    public void addGrocery(Grocery grocery) {
        groceries.add(grocery);
    }

    public Grocery getGroceryByName(String name) {
        for (Grocery grocery : groceries) {
            if (grocery.getName().equalsIgnoreCase(name)) {
                return grocery;
            }
        }
        return null;
    }

    public void removeGrocery(String name) {
        groceries.removeIf(grocery -> grocery.getName().equalsIgnoreCase(name));
    }

    public ArrayList<Grocery> getGroceries() {
        return groceries;
    }

    public ArrayList<Grocery> getImportantGroceries() {
        ArrayList<Grocery> importantGroceries = new ArrayList<>();
        for (Grocery grocery : groceries) {
            if (grocery.isImportant()) {
                importantGroceries.add(grocery);
            }
        }
        return importantGroceries;
    }

}
