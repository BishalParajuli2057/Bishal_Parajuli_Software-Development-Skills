package com.example.myapplication;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ListGroceryFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ListGroceryFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private GroceryListAdapter adapter;
    private RecyclerView recyclerView;

    public ListGroceryFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment ListGroceryFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ListGroceryFragment newInstance(String param1, String param2) {
        ListGroceryFragment fragment = new ListGroceryFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_list_grocery, container, false);

        // Initialize the RecyclerView
        recyclerView = view.findViewById(R.id.rvGroceries);

        // Set the LinearLayoutManager with the context of the containing activity
        // Inside your Fragment
        if(getActivity() != null) {
            adapter = new GroceryListAdapter(getActivity(), ListGrocery.getInstance().getGroceries());
        }


        // Initialize the adapter and set it to the RecyclerView
        // Inside your Fragment
        adapter = new GroceryListAdapter(getContext(), ListGrocery.getInstance().getGroceries());
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);

        return view;
    }
}