package com.example.myapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

public class AddGroceryFragment extends Fragment {

    public AddGroceryFragment() {
        // Required empty public constructor
    }

    public static AddGroceryFragment newInstance() {
        return new AddGroceryFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_add_grocery, container, false);

        EditText editGroceryName = view.findViewById(R.id.editGroceryName);
        EditText editGroceryNote = view.findViewById(R.id.editGroceryNote);
        Button buttonAddGrocery = view.findViewById(R.id.buttonAddGrocery);
        CheckBox checkImportant = view.findViewById(R.id.checkImportant);

        buttonAddGrocery.setOnClickListener(v -> {

            String name = editGroceryName.getText().toString().trim();
            String note = editGroceryNote.getText().toString().trim();
            boolean isImportant = checkImportant.isChecked();

            if (!name.isEmpty()) {

                ListGrocery.getInstance().addGrocery(
                        new Grocery(name, note, isImportant)
                );

                // Clear input fields
                editGroceryName.setText("");
                editGroceryNote.setText("");
                checkImportant.setChecked(false);

                // Confirmation message
                Toast.makeText(
                        getContext(),
                        "Grocery added successfully",
                        Toast.LENGTH_SHORT
                ).show();

            } else {

                Toast.makeText(
                        getContext(),
                        "Please enter a grocery name",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        return view;
    }
}