package com.example.myapplication;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link BottomFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class BottomFragment extends Fragment {


    private TextView textImportant;

    public BottomFragment() {
        // Required empty public constructor
    }

    public static BottomFragment newInstance() {
        return new BottomFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_bottom, container, false);
        textImportant = view.findViewById(R.id.textImportant);
        updateImportantItems();

        return view;
    }
    private void updateImportantItems() {
        ArrayList<Grocery> importantGroceries = ListGrocery.getInstance().getImportantGroceries();
        StringBuilder importantItemsText = new StringBuilder("Supertärkeät:\n");

        for (Grocery grocery : importantGroceries) {
            importantItemsText.append("- ").append(grocery.getName()).append("\n");
        }

        if (importantGroceries.isEmpty()) {
            importantItemsText.append("Ei supertärkeitä kohteita.");
        }

        textImportant.setText(importantItemsText.toString());
    }


}