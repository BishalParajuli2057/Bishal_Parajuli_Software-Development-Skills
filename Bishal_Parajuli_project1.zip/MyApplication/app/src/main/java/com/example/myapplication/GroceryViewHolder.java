package com.example.myapplication;

public class GroceryViewHolder {
    String edittext1;
    String editText2;
    String edittext3;
    int image1;
    int image2;

    public GroceryViewHolder(String edittext1, String editText2, String edittext3, int image1, int image2) {
        this.edittext1 = edittext1;
        this.editText2 = editText2;
        this.edittext3 = edittext3;
        this.image1 = image1;
        this.image2 = image2;
    }

    public String getEdittext1() {
        return edittext1;
    }

    public String getEditText2() {
        return editText2;
    }

    public String getEdittext3() {
        return edittext3;
    }

    public int getImage1() {
        return image1;
    }

    public int getImage2() {
        return image2;
    }
}
