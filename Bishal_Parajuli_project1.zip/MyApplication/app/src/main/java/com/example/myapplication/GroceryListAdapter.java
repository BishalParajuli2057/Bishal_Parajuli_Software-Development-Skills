package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class GroceryListAdapter extends RecyclerView.Adapter<GroceryListAdapter.GroceryViewHolder> {
    private final ArrayList<Grocery> groceries;
    private LayoutInflater inflater;

    // Constructor
    public GroceryListAdapter(Context context, ArrayList<Grocery> groceries) {
        this.inflater = LayoutInflater.from(context);
        this.groceries = groceries;
    }

    @NonNull
    @Override
    public GroceryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.layout1, parent, false);
        return new GroceryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GroceryViewHolder holder, int position) {
        Grocery grocery = groceries.get(position);
        holder.textGroceryName.setText(grocery.getName());
        holder.textGroceryNote.setText(grocery.getNote());
    }

    @Override
    public int getItemCount() {
        return groceries.size();
    }

    // ViewHolder class
    public static class GroceryViewHolder extends RecyclerView.ViewHolder {
        final TextView textGroceryName, textGroceryNote;

        public GroceryViewHolder(View itemView) {
            super(itemView);
            textGroceryName = itemView.findViewById(R.id.textGroceryName);
            textGroceryNote = itemView.findViewById(R.id.textGroceryNote);
        }
    }
}

